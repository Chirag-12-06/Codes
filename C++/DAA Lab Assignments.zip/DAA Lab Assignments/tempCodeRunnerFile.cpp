ADAABAABA";
    string pat = "AABA"