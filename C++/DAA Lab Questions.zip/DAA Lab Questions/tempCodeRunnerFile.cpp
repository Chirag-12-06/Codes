 s=sequence(s1,dir);
    cout<<